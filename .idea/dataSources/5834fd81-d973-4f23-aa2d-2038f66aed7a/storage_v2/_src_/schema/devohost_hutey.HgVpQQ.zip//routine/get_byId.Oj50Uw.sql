create
    definer = devohost_hutey@`%` procedure get_byId(IN userId int, OUT user_login varchar(30),
                                                    OUT user_pass varchar(30), OUT user_email varbinary(50),
                                                    OUT user_phone varchar(15), OUT user_created timestamp)
begin
     select login into user_login from users where  user_id = userId;
     select password into user_pass from users where  user_id = userId;
     select email into user_email from users where  user_id = userId;
     select phone into user_phone from users where  user_id = userId;
     select created into user_created from users where  user_id = userId;
 end;

