create
    definer = devohost_hutey@`%` procedure getAll()
begin
    select * from users;
end;

