create
    definer = devohost_hutey@`%` procedure counter(OUT amount int)
begin
    select count(*) into amount from users;
end;

